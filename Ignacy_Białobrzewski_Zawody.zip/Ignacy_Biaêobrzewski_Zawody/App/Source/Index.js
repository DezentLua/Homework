const ButtonSubmit = document.querySelector("#button-submit")
const ButtonClear = document.querySelector("#button-clear")
const Form = document.querySelector("#form-object")

function OnButtonSubmit(Event)
{
    console.log(Event)
}

function OnButtonClear(Event)
{
    let Inputs = document.querySelectorAll("input")

    for (Index in Inputs)
    {
        let Input = Inputs[Index]

        if (Input != ButtonSubmit && Input != ButtonClear)
        {
            Input.value = null
        }
    }
}

ButtonSubmit.addEventListener("click", OnButtonSubmit)
ButtonClear.addEventListener("click", OnButtonClear)