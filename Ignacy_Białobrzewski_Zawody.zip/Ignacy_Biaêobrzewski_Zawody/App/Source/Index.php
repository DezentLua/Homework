<?php

// Ignacy Białobrzewski 1TP

$InputLocation = $_POST["input-location"];
$InputReferee = $_POST["input-referee"];
$InputDate = $_POST["input-date"];

class Query
{
    private string $QueryHostname;
    private string $QueryUsername;
    private string $QueryPassword;
    private string $QueryDatabase;
    private object $QueryConnection;
    private int $QuertPort;

    public function PrepareConnection(): mysqli
    {
        $this -> QueryConnection = New mysqli(
            $this -> QueryHostname,
            $this -> QueryUsername,
            $this -> QueryPassword,
            $this -> QueryDatabase,
            $this -> QuertPort,
        );

        return $this -> QueryConnection;
    }

    public function CloseConnection()
    {
        $this -> QueryConnection -> close();
    }

    public function SubmitQuery(string $Query): void
    {
        $this -> QueryConnection -> query($Query);
    }

    public function SetHostname(string $Hostname): void
    {
        $this -> QueryHostname = $Hostname;
    }

    public function SetUsername(string $Username): void
    {
        $this -> QueryUsername = $Username;
    }

    public function SetPassword(string $Password): void
    {
        $this -> QueryPassword = $Password;
    }

    public function SetDatabase(string $Database): void
    {
        $this -> QueryDatabase = $Database;
    }

    public function SetPort(int $Port): void
    {
        $this -> QuertPort = $Port;
    }
}

$NewQuery = New Query();
$NewQuery -> SetHostname("localhost");
$NewQuery -> SetUsername("root");
$NewQuery -> SetPassword("");
$NewQuery -> SetDatabase("mydatabase");
$NewQuery -> SetPort(3306);
$NewQuery -> PrepareConnection();

$NewQuery -> SubmitQuery("CREATE TABLE IF NOT EXISTS zawody (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    PLACE VARCHAR(30),
    REFEREE VARCHAR(30),
    DATEOF DATE
)");

$NewQuery -> SubmitQuery("INSERT INTO `zawody`(`PLACE`, `REFEREE`, `DATEOF`) VALUES ('$InputLocation','$InputReferee','$InputDate')");
$NewQuery -> CloseConnection();
