const Form = document.querySelector("#search-form")
const Input = document.querySelector("#search-input")
const Submit = document.querySelector("#search-bar-submit")

function OnSubmit(Event) {
    Event.preventDefault()

    if (Input.value == "") {
        return console.log("No searchphrase was given")
    }

    window.location = `https://google.com/search?q=${Input.value}`
}

Submit.addEventListener("click", OnSubmit)
Form.addEventListener("submit", OnSubmit)