<?php

// Imports
$Database = require("./Database.php");

// Captures
$InputTableQuery = $_POST["input-table-query"];
$InputTableName = $_POST["input-table-database"];

// Main
$JSONResource = fopen("Host.json", "r");
$JSONContent = fread($JSONResource, 1000);
$JSONDecode = json_decode($JSONContent);

$Database->SetHostname($JSONDecode->DatabaseHostname);
$Database->SetUsername($JSONDecode->DatabaseUsername);
$Database->SetPassword($JSONDecode->DatabasePassword);
$Database->SetName($InputTableName);
$Database->SetPort($JSONDecode->DatabasePort);
$Database->Prepare();
$Database->Submit($InputTableQuery);

fclose($JSONResource);

