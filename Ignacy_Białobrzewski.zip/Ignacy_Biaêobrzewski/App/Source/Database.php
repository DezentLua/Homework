<?php

class Database
{
    private object $DatabaseConnection;
    private string $DatabaseHostname;
    private string $DatabaseUsername;
    private string $DatabasePassword;
    private string $DatabaseName;
    private int $DatabasePort;

    public function Prepare(): void
    {
        $this -> DatabaseConnection = new mysqli(
            $this -> DatabaseHostname,
            $this -> DatabaseUsername,
            $this -> DatabasePassword,
            $this -> DatabaseName,
            $this -> DatabasePort,
        );
    }
    public function Close(): void 
    {
        $this->DatabaseConnection->close();
    }
    public function Submit(string $Query): void
    {
        $this -> DatabaseConnection->query($Query);
    }
    public function SetHostname(string $Hostname): void
    {
        $this -> DatabaseHostname = $Hostname;
    }
    public function SetUsername(string $Username): void
    {
        $this -> DatabaseUsername = $Username;
    }
    public function SetPassword(string $Password): void
    {
        $this -> DatabasePassword = $Password;
    }
    public function SetName(string $Name): void
    {
        $this->DatabaseName = $Name;
    }
    public function SetPort(int $Port): void
    {
        $this->DatabasePort = $Port;
    }
}

return new Database;