<?php 

// Ignacy Białobrzewski 1TP

class Query {
    private string $QueryDatabase;
    private string $QueryUsername;
    private string $QueryPassword;
    private string $QueryHostname;
    private object $QueryConnection;
    private int $QueryPort;

    public function Prepare(): void
    {
        $this -> QueryConnection = New mysqli(
            $this -> QueryHostname,
            $this -> QueryUsername,
            $this -> QueryPassword,
            $this -> QueryDatabase,
            $this -> QueryPort,
        );
    }

    public function Submit(string $Query): void
    {
        $this -> QueryConnection -> query($Query);
    }

    public function SetDatabase(string $Database): void
    {
        $this -> QueryDatabase = $Database;
    }

    public function SetUsername(string $Username): void
    {
        $this -> QueryUsername = $Username;
    }

    public function SetPassword(string $Password): void
    {
        $this -> QueryPassword = $Password;
    }

    public function SetHostname(string $Hostname): void
    {
        $this -> QueryHostname = $Hostname;
    }

    public function SetPort(int $Port): void
    {
        $this -> QueryPort = $Port;
    }
}

$HashedPassword = hash("sha256", "password12345");
$Cash = 520;
$Bank = 12321;

$NewQuery = New Query();
$NewQuery -> SetDatabase("mydatabase");
$NewQuery -> SetUsername("root");
$NewQuery -> SetPassword("");
$NewQuery -> SetHostname("localhost");
$NewQuery -> SetPort(3306);
$NewQuery -> Prepare();

$NewQuery -> Submit("CREATE TABLE IF NOT EXISTS `PLAYER` (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user VARCHAR(22),
    pass VARCHAR(22),
    cash BIGINT,
    bank BIGINT
)");

$NewQuery -> Submit("INSERT INTO `player` (`user`, `pass`, `cash`, `bank`) VALUES ('Ignacy', '$HashedPassword', '$Cash', '$Bank')");